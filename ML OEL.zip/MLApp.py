import os
import pickle
import streamlit as st
from streamlit_option_menu import option_menu


# Set page configuration
st.set_page_config(page_title="Disease predictor",
                   layout="wide",
                   page_icon="👩‍⚕️")

    
# getting the working directory of the main.py
working_dir = os.path.dirname(os.path.abspath(__file__))

# loading the saved models

diabetes_model = pickle.load(open(f'C:/Users/Admin/Desktop/ML OEL/saved_models/diabetes_log_reg_model.sav', 'rb'))

heart_disease_model = pickle.load(open(f'C:/Users/Admin/Desktop/ML OEL/saved_models/knn_model_heart.sav', 'rb'))

parkinsons_model = pickle.load(open(f'C:/Users/Admin/Desktop/ML OEL/saved_models/knn_model_parkinsons.sav', 'rb'))

css = '''
<style>
    [data-testid="stAppViewContainer"] {
      background-image: url("https://img.freepik.com/free-vector/abstract-medical-wallpaper-template-design_53876-61805.jpg?w=900&t=st=1720359209~exp=1720359809~hmac=78f4de6cf155c3600e33c7da1d90d44c3599bcfc5a9347137d45f7e63bce26fc"); 
      background-size: cover;  
    }
    .st-emotion-cache-10trblm {
        text-align:center;    
    }
    .st-emotion-cache-1azthvy input {
        font-size: x-large;    
    }
    b, strong {
        font-size: large;
    }
    p {
        text-align: center;
        font-size: large;
        font-weight: 600;
    }
    .st-emotion-cache-1r6slb0 {
        margin-top: 30px;    
    }
</style>
'''
 ##MainMenu {visibility: hidden;}
 #footer {visibility: hidden;}
 #header {visibility: hidden;}
st.markdown(css, unsafe_allow_html=True)

# sidebar for navigation
with st.sidebar:
    selected = option_menu('Multiple Disease Prediction System',

                           ['Diabetes Prediction',
                            'Heart Disease Prediction',
                            'Parkinsons Prediction'],
                           menu_icon='prescription2',

                           icons=['capsule', 'heart-pulse-fill', 'person-wheelchair'],
                           default_index=0)


# Diabetes Prediction Page
if selected == 'Diabetes Prediction':
    st.title('Diabetes Prediction - Created by Fatima Siddiqui')


    # Instructions
    st.write('Please enter the following information for diabetes prediction')

    # Getting the input data from the user
    col1, col2, col3 = st.columns(3)

    with col1:
        Pregnancies = st.number_input('**Number of Pregnancies**', min_value=0, step=1, help='Enter the number of times you have been pregnant')

    with col2:
        Glucose = st.number_input('**Glucose Level**', min_value=0, help='Enter your glucose level in mg/dL')

    with col3:
        BloodPressure = st.number_input('**Blood Pressure value**', min_value=0, help='Enter your blood pressure value in mm Hg')

    with col1:
        SkinThickness = st.number_input('**Skin Thickness value**', min_value=0, help='Enter your skin thickness in mm')

    with col2:
        Insulin = st.number_input('**Insulin Level**', min_value=0, help='Enter your insulin level in IU/mL')

    with col3:
        BMI = st.number_input('**BMI value**', min_value=0.0, help='Enter your Body Mass Index value')

    with col1:
        DiabetesPedigreeFunction = st.number_input('**Diabetes Pedigree Function value**', min_value=0.0, help='Enter your diabetes pedigree function value')

    with col2:
        Age = st.number_input('**Age of the Person**', min_value=0, help='Enter your age')
        
     # code for Prediction
    diab_diagnosis = ''
    user_input = [Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age]

    if st.button('Diabetes Test Result'):
        diab_prediction = diabetes_model.predict([user_input])

        if diab_prediction[0] == 1:
            diab_diagnosis = 'The person is diabetic'
            precautions = '''
                **Precautionary Measures:**
                1. Follow a healthy diet rich in fruits, vegetables, and whole grains.
                2. Engage in regular physical activity, such as brisk walking, for at least 30 minutes a day.
                3. Monitor blood sugar levels regularly as advised by your healthcare provider.
                4. Take medication as prescribed and never skip doses.
                5. Maintain a healthy weight to help control blood sugar levels.
                6. Avoid smoking and limit alcohol consumption.
                7. Manage stress through activities like yoga, meditation, or hobbies.
            '''
        else:
            diab_diagnosis = 'The person is not diabetic'
            precautions = '''
                **Precautionary Measures:**
                1. Maintain a healthy weight through a balanced diet and regular exercise.
                2. Monitor your blood sugar levels periodically, especially if you have a family history of diabetes.
                3. Stay active to improve insulin sensitivity and maintain overall health.
                4. Avoid excessive consumption of sugary foods and beverages.
                5. Get regular medical check-ups to monitor your health status.
            '''

        st.success(diab_diagnosis)
        st.write("### Summary and Results")
        st.markdown(f"""
        - **Number of Pregnancies:** {Pregnancies}
        - **Glucose Level:** {Glucose} mg/dL
        - **Blood Pressure:** {BloodPressure} mm Hg
        - **Skin Thickness:** {SkinThickness} mm
        - **Insulin Level:** {Insulin} IU/mL
        - **BMI:** {BMI}
        - **Diabetes Pedigree Function:** {DiabetesPedigreeFunction}
        - **Age:** {Age}
        - **Result:** {diab_diagnosis}
        """)
        st.markdown(precautions)
    
    

# Heart Disease Prediction Page
if selected == 'Heart Disease Prediction':
    st.title('Heart Disease Prediction - Created by Barira Babar')
    st.write('Please enter the following information for heart disease prediction')

    col1, col2, col3 = st.columns(3)

    with col1:
        age = st.number_input('Age', min_value=0, help='Enter your age')

    with col2:
        sex = st.selectbox('Sex', options=['Male', 'Female'], help='Select your sex')

    with col3:
        cp = st.number_input('Chest Pain types', min_value=0, help='Enter your chest pain type (0-3)')

    with col1:
        trestbps = st.number_input('Resting Blood Pressure', min_value=0, help='Enter your resting blood pressure in mm Hg')

    with col2:
        chol = st.number_input('Serum Cholestoral in mg/dl', min_value=0, help='Enter your serum cholestoral in mg/dl')

    with col3:
        fbs = st.number_input('Fasting Blood Sugar > 120 mg/dl', min_value=0, help='Enter 1 if true, 0 otherwise')

    with col1:
        restecg = st.number_input('Resting Electrocardiographic results', min_value=0, help='Enter your resting ECG results (0-2)')

    with col2:
        thalach = st.number_input('Maximum Heart Rate achieved', min_value=0, help='Enter your maximum heart rate achieved')

    with col3:
        exang = st.number_input('Exercise Induced Angina', min_value=0, help='Enter 1 if true, 0 otherwise')

    with col1:
        oldpeak = st.number_input('ST depression induced by exercise', min_value=0.0, help='Enter the ST depression induced by exercise relative to rest')

    with col2:
        slope = st.number_input('Slope of the peak exercise ST segment', min_value=0, help='Enter the slope of the peak exercise ST segment (0-2)')

    with col3:
        ca = st.number_input('Major vessels colored by flourosopy', min_value=0, help='Enter the number of major vessels (0-3)')

    with col1:
        thal = st.number_input('Thalassemia', min_value=0, help='Enter the thalassemia value (1-3)')

    heart_diagnosis = ''
    user_input = [age, 1 if sex == 'Male' else 0, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]

    if st.button('Heart Disease Test Result'):
        heart_prediction = heart_disease_model.predict([user_input])

        if heart_prediction[0] == 1:
            heart_diagnosis = 'The person is having heart disease'
            precautions = '''
                **Precautionary Measures:**
                1. Adopt a heart-healthy diet rich in fruits, vegetables, whole grains, and lean proteins.
                2. Engage in regular physical activity, aiming for at least 150 minutes of moderate exercise per week.
                3. Avoid smoking and limit alcohol consumption.
                4. Monitor your blood pressure, cholesterol levels, and diabetes regularly.
                5. Take medications as prescribed and follow your doctor's advice.
                6. Manage stress through relaxation techniques like yoga, meditation, or hobbies.
            '''
        else:
            heart_diagnosis = 'The person does not have any heart disease'
            precautions = '''
                **Precautionary Measures:**
                1. Maintain a balanced diet and exercise regularly to keep your heart healthy.
                2. Avoid smoking and excessive alcohol consumption.
                3. Get regular check-ups to monitor your heart health.
                4. Manage stress and maintain a healthy weight.
            '''

        st.success(heart_diagnosis)
        st.write("### Summary and Results")
        st.markdown(f"""
        - **Age:** {age}
        - **Sex:** {sex}
        - **Chest Pain Types:** {cp}
        - **Resting Blood Pressure:** {trestbps} mm Hg
        - **Serum Cholestoral:** {chol} mg/dl
        - **Fasting Blood Sugar > 120 mg/dl:** {fbs}
        - **Resting ECG Results:** {restecg}
        - **Maximum Heart Rate Achieved:** {thalach}
        - **Exercise Induced Angina:** {exang}
        - **ST Depression Induced by Exercise:** {oldpeak}
        - **Slope of the Peak Exercise ST Segment:** {slope}
        - **Major Vessels Colored by Flourosopy:** {ca}
        - **Thalassemia:** {thal}
        - **Result:** {heart_diagnosis}
        """)
        st.markdown(precautions)


# Parkinson's Prediction Page
if selected == "Parkinsons Prediction":
    st.title("Parkinson's Disease Prediction - Created by Aqsa Asif")
    st.write("Please enter the following information for Parkinson's disease prediction")

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        fo = st.number_input('MDVP:Fo(Hz)', min_value=0.0, help='Enter MDVP:Fo(Hz)')

    with col2:
        fhi = st.number_input('MDVP:Fhi(Hz)', min_value=0.0, help='Enter MDVP:Fhi(Hz)')

    with col3:
        flo = st.number_input('MDVP:Flo(Hz)', min_value=0.0, help='Enter MDVP:Flo(Hz)')

    with col4:
        Jitter_percent = st.number_input('MDVP:Jitter(%)', min_value=0.0, help='Enter MDVP:Jitter(%)')

    with col5:
        Jitter_Abs = st.number_input('MDVP:Jitter(Abs)', min_value=0.0, help='Enter MDVP:Jitter(Abs)')

    with col1:
        RAP = st.number_input('MDVP:RAP', min_value=0.0, help='Enter MDVP:RAP')

    with col2:
        PPQ = st.number_input('MDVP:PPQ', min_value=0.0, help='Enter MDVP:PPQ')

    with col3:
        DDP = st.number_input('Jitter:DDP', min_value=0.0, help='Enter Jitter:DDP')

    with col4:
        Shimmer = st.number_input('MDVP:Shimmer', min_value=0.0, help='Enter MDVP:Shimmer')

    with col5:
        Shimmer_dB = st.number_input('MDVP:Shimmer(dB)', min_value=0.0, help='Enter MDVP:Shimmer(dB)')

    with col1:
        APQ3 = st.number_input('Shimmer:APQ3', min_value=0.0, help='Enter Shimmer:APQ3')

    with col2:
        APQ5 = st.number_input('Shimmer:APQ5', min_value=0.0, help='Enter Shimmer:APQ5')

    with col3:
        APQ = st.number_input('MDVP:APQ', min_value=0.0, help='Enter MDVP:APQ')

    with col4:
        DDA = st.number_input('Shimmer:DDA', min_value=0.0, help='Enter Shimmer:DDA')

    with col5:
        NHR = st.number_input('NHR', min_value=0.0, help='Enter NHR')

    with col1:
        HNR = st.number_input('HNR', min_value=0.0, help='Enter HNR')

    with col2:
        RPDE = st.number_input('RPDE', min_value=0.0, help='Enter RPDE')

    with col3:
        DFA = st.number_input('DFA', min_value=0.0, help='Enter DFA')

    with col4:
        spread1 = st.number_input('spread1', min_value=0.0, help='Enter spread1')

    with col5:
        spread2 = st.number_input('spread2', min_value=0.0, help='Enter spread2')

    with col1:
        D2 = st.number_input('D2', min_value=0.0, help='Enter D2')

    with col2:
        PPE = st.number_input('PPE', min_value=0.0, help='Enter PPE')

    parkinsons_diagnosis = ''
    user_input = [fo, fhi, flo, Jitter_percent, Jitter_Abs, RAP, PPQ, DDP, Shimmer, Shimmer_dB, APQ3, APQ5, APQ, DDA, NHR, HNR, RPDE, DFA, spread1, spread2, D2, PPE]

    if st.button("Parkinson's Test Result"):
        parkinsons_prediction = parkinsons_model.predict([user_input])

        if parkinsons_prediction[0] == 1:
            parkinsons_diagnosis = "The person has Parkinson's disease"
            precautions = '''
                **Precautionary Measures:**
                1. Follow a balanced diet with plenty of fruits, vegetables, and whole grains.
                2. Engage in regular physical activity to maintain muscle strength and flexibility.
                3. Take medications as prescribed and attend regular medical appointments.
                4. Consider physical, occupational, and speech therapy to manage symptoms.
                5. Stay socially active and engage in hobbies to maintain mental health.
                6. Make home modifications to ensure safety and ease of movement.
            '''
        else:
            parkinsons_diagnosis = "The person does not have Parkinson's disease"
            precautions = '''
                **Precautionary Measures:**
                1. Maintain a healthy lifestyle with a balanced diet and regular exercise.
                2. Stay mentally active with puzzles, reading, and other cognitive activities.
                3. Regularly check in with your healthcare provider for routine assessments.
            '''

        st.success(parkinsons_diagnosis)
        st.write("### Summary and Results")
        st.markdown(f"""
        - **MDVP:Fo(Hz):** {fo}
        - **MDVP:Fhi(Hz):** {fhi}
        - **MDVP:Flo(Hz):** {flo}
        - **MDVP:Jitter(%):** {Jitter_percent}
        - **MDVP:Jitter(Abs):** {Jitter_Abs}
        - **MDVP:RAP:** {RAP}
        - **MDVP:PPQ:** {PPQ}
        - **Jitter:DDP:** {DDP}
        - **MDVP:Shimmer:** {Shimmer}
        - **MDVP:Shimmer(dB):** {Shimmer_dB}
        - **Shimmer:APQ3:** {APQ3}
        - **Shimmer:APQ5:** {APQ5}
        - **MDVP:APQ:** {APQ}
        - **Shimmer:DDA:** {DDA}
        - **NHR:** {NHR}
        - **HNR:** {HNR}
        - **RPDE:** {RPDE}
        - **DFA:** {DFA}
        - **Spread1:** {spread1}
        - **Spread2:** {spread2}
        - **D2:** {D2}
        - **PPE:** {PPE}
        - **Result:** {parkinsons_diagnosis}
        """)
        st.markdown(precautions)